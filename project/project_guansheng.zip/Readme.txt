Jupyter notebook, PDF of the Jupyter notebook, the slides of summary were submitted. 

Due to the limit of upload size, the image data can be downloaded from this link:
https://zhaw-my.sharepoint.com/:u:/g/personal/dugua001_students_zhaw_ch/EbsgBY4_jQBElQJKGMe5yWQBVYfx8Md5dr9lkdehpy4guQ?e=04Qia1

Image augmentation was used instead of preprocessing. A sample of images after augmentation was provided in the slides and in the Jupyter notebook. 

The trained model was provided instead of segmentation masks. A sample of segmentation masks was provided in the slides and in the Jupyter notebook. 
